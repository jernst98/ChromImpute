See https://ernstlab.biolchem.ucla.edu/ChromImpute/ for more information on ChromImpute

ChromImpute uses Apache Commons library org.apache.commons.compress for reading tar files
